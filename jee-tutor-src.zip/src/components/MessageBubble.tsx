import { Message } from '../lib/supabase';
import { Copy, Check } from 'lucide-react';
import { useState, useEffect } from 'react';
import { marked } from 'marked';
import DOMPurify from 'dompurify';

interface MessageBubbleProps {
  message: Message;
}

export function MessageBubble({ message }: MessageBubbleProps) {
  const [copied, setCopied] = useState(false);
  const [renderHTML, setRenderHTML] = useState('');
  const isUser = message.role === 'user';

  const handleCopy = () => {
    navigator.clipboard.writeText(message.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  useEffect(() => {
    if (!isUser) {
      try {
        const html = marked(message.content) as string;
        const sanitized = DOMPurify.sanitize(html);
        setRenderHTML(sanitized);

        setTimeout(() => {
          const mathElements = document.querySelectorAll('[data-msg-id="' + message.id + '"] .math');
          mathElements.forEach((el) => {
            try {
              window.katex?.render(el.textContent || '', el, { throwOnError: false });
            } catch (e) {
              console.error('KaTeX render error:', e);
            }
          });
        }, 0);
      } catch (error) {
        console.error('Markdown parse error:', error);
      }
    }
  }, [message.content, message.id, isUser]);

  const renderContent = () => {
    if (isUser) {
      return <p className="whitespace-pre-wrap text-sm">{message.content}</p>;
    }

    return (
      <div
        data-msg-id={message.id}
        className="prose prose-sm max-w-none text-sm dark:prose-invert prose-pre:bg-gray-800 prose-pre:text-gray-100"
        dangerouslySetInnerHTML={{ __html: renderHTML }}
      />
    );
  };

  return (
    <div className={`flex ${isUser ? 'justify-end' : 'justify-start'} mb-4`}>
      <div
        className={`max-w-xs md:max-w-md lg:max-w-lg rounded-lg px-4 py-3 ${
          isUser
            ? 'bg-blue-600 text-white rounded-br-none'
            : 'bg-gray-200 text-gray-900 rounded-bl-none'
        }`}
      >
        {message.image_url && !isUser && (
          <div className="mb-3">
            <img
              src={message.image_url}
              alt="Referenced image"
              className="max-w-full h-auto rounded"
            />
          </div>
        )}

        {message.image_url && isUser && (
          <div className="mb-3">
            <img
              src={message.image_url}
              alt="Uploaded image"
              className="max-w-full h-auto rounded"
            />
          </div>
        )}

        <div className="text-sm">{renderContent()}</div>

        {!isUser && (
          <button
            onClick={handleCopy}
            className="mt-2 text-xs opacity-70 hover:opacity-100 flex items-center gap-1 transition-opacity"
          >
            {copied ? (
              <>
                <Check size={14} />
                Copied
              </>
            ) : (
              <>
                <Copy size={14} />
                Copy
              </>
            )}
          </button>
        )}
      </div>
    </div>
  );
}
