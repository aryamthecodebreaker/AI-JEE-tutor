import { useEffect, useRef, useState } from 'react';
import { Message, Conversation } from '../lib/supabase';
import { MessageBubble } from './MessageBubble';
import { ChatInput } from './ChatInput';
import { Loader } from 'lucide-react';

interface ChatContainerProps {
  messages: Message[];
  isLoading: boolean;
  currentConversation: Conversation | null;
  onSendMessage: (message: string, imageBase64?: string, imageMimeType?: string) => void;
}

export function ChatContainer({
  messages,
  isLoading,
  currentConversation,
  onSendMessage,
}: ChatContainerProps) {
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const [autoScroll, setAutoScroll] = useState(true);
  const messagesContainerRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    if (autoScroll) {
      messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isLoading, autoScroll]);

  const handleScroll = () => {
    if (messagesContainerRef.current) {
      const { scrollHeight, scrollTop, clientHeight } = messagesContainerRef.current;
      const isAtBottom = scrollHeight - scrollTop - clientHeight < 50;
      setAutoScroll(isAtBottom);
    }
  };

  const EXAMPLE_QUESTIONS = [
    'Explain Newton\'s laws of motion',
    'How does projectile motion work?',
    'What is the difference between elastic and inelastic collisions?',
    'Explain electromagnetic induction',
  ];

  return (
    <div className="flex flex-col h-full bg-white">
      <div className="flex-shrink-0 bg-gradient-to-r from-blue-600 to-blue-700 text-white p-4 shadow-md">
        <h1 className="text-2xl font-bold">JEE Physics Tutor</h1>
        {currentConversation && (
          <p className="text-sm text-blue-100 mt-1">{currentConversation.title}</p>
        )}
      </div>

      <div
        ref={messagesContainerRef}
        onScroll={handleScroll}
        className="flex-1 overflow-y-auto p-4 space-y-4"
      >
        {messages.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full text-center py-12">
            <div className="mb-6">
              <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto">
                <div className="text-3xl">📚</div>
              </div>
            </div>
            <h2 className="text-2xl font-bold text-gray-800 mb-2">Welcome to Physics Tutor</h2>
            <p className="text-gray-600 mb-6 max-w-md">
              Ask any physics question and get detailed, step-by-step explanations from your AI tutor.
            </p>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 w-full max-w-lg">
              {EXAMPLE_QUESTIONS.map((question, idx) => (
                <button
                  key={idx}
                  onClick={() => onSendMessage(question)}
                  className="p-3 text-left bg-gray-100 hover:bg-gray-200 rounded-lg text-sm text-gray-700 transition-colors border border-gray-300"
                >
                  {question}
                </button>
              ))}
            </div>
          </div>
        ) : (
          <>
            {messages.map((message) => (
              <MessageBubble key={message.id} message={message} />
            ))}
            {isLoading && (
              <div className="flex justify-start mb-4">
                <div className="bg-gray-200 rounded-lg px-4 py-3 rounded-bl-none flex items-center gap-2">
                  <Loader size={16} className="animate-spin text-gray-600" />
                  <span className="text-sm text-gray-600">Thinking...</span>
                </div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </>
        )}
      </div>

      <ChatInput onSendMessage={onSendMessage} isLoading={isLoading} />
    </div>
  );
}
