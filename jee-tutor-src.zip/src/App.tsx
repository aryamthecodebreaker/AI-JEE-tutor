import { useState, useEffect } from 'react';
import { getChatResponse } from './lib/gemini';
import { Sidebar } from './components/Sidebar';
import { ChatContainer } from './components/ChatContainer';
import { AlertCircle } from 'lucide-react';

interface Conversation {
  id: string;
  title: string;
  created_at: string;
  updated_at: string;
}

interface Message {
  id: string;
  conversation_id: string;
  role: 'user' | 'assistant';
  content: string;
  image_url: string | null;
  created_at: string;
}

function App() {
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [currentConversationId, setCurrentConversationId] = useState<string | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const currentConversation = conversations.find((c) => c.id === currentConversationId);

  useEffect(() => {
    loadConversations();
  }, []);

  useEffect(() => {
    if (currentConversationId) {
      loadMessages(currentConversationId);
    }
  }, [currentConversationId]);

  const loadConversations = () => {
    try {
      const stored = localStorage.getItem('jee_conversations');
      const data: Conversation[] = stored ? JSON.parse(stored) : [];
      const sorted = data.sort((a, b) => new Date(b.updated_at).getTime() - new Date(a.updated_at).getTime());
      setConversations(sorted);
      if (!currentConversationId && sorted.length > 0) {
        setCurrentConversationId(sorted[0].id);
      }
    } catch (err) {
      console.error('Error loading conversations:', err);
    }
  };

  const loadMessages = (conversationId: string) => {
    try {
      const stored = localStorage.getItem(`jee_messages_${conversationId}`);
      const data: Message[] = stored ? JSON.parse(stored) : [];
      setMessages(data);
    } catch (err) {
      console.error('Error loading messages:', err);
    }
  };

  const handleNewConversation = () => {
    const newConv: Conversation = {
      id: Math.random().toString(36).substr(2, 9),
      title: 'New Conversation',
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    };
    const stored = localStorage.getItem('jee_conversations');
    const existing: Conversation[] = stored ? JSON.parse(stored) : [];
    localStorage.setItem('jee_conversations', JSON.stringify([newConv, ...existing]));
    setConversations([newConv, ...conversations]);
    setCurrentConversationId(newConv.id);
    setMessages([]);
    setSidebarOpen(false);
  };

  const handleDeleteConversation = (id: string) => {
    const updated = conversations.filter((c) => c.id !== id);
    localStorage.setItem('jee_conversations', JSON.stringify(updated));
    localStorage.removeItem(`jee_messages_${id}`);
    setConversations(updated);
    if (currentConversationId === id) {
      if (updated.length > 0) {
        setCurrentConversationId(updated[0].id);
      } else {
        setCurrentConversationId(null);
        setMessages([]);
      }
    }
  };

  const handleSendMessage = async (
    userMessage: string,
    imageBase64?: string,
    imageMimeType?: string
  ) => {
    if (!currentConversationId) {
      setError('No conversation selected');
      return;
    }

    try {
      setError(null);

      const userMsg: Message = {
        id: Math.random().toString(36).substr(2, 9),
        conversation_id: currentConversationId,
        role: 'user',
        content: userMessage,
        image_url: null,
        created_at: new Date().toISOString(),
      };

      const updatedMessages = [...messages, userMsg];
      setMessages(updatedMessages);
      localStorage.setItem(`jee_messages_${currentConversationId}`, JSON.stringify(updatedMessages));
      setIsLoading(true);

      const conversationHistory = messages
        .filter((m) => m.role === 'user' || m.role === 'assistant')
        .map((m) => ({
          role: m.role,
          content: m.content,
        }));

      conversationHistory.push({
        role: 'user',
        content: userMessage,
      });

      const response = await getChatResponse(
        userMessage,
        conversationHistory,
        imageBase64,
        imageMimeType
      );

      const assistantMsg: Message = {
        id: Math.random().toString(36).substr(2, 9),
        conversation_id: currentConversationId,
        role: 'assistant',
        content: response,
        image_url: null,
        created_at: new Date().toISOString(),
      };

      const finalMessages = [...updatedMessages, assistantMsg];
      setMessages(finalMessages);
      localStorage.setItem(`jee_messages_${currentConversationId}`, JSON.stringify(finalMessages));

      const title = userMessage.length > 50 ? userMessage.substring(0, 47) + '...' : userMessage;
      const stored = localStorage.getItem('jee_conversations');
      const convs: Conversation[] = stored ? JSON.parse(stored) : [];
      const updatedConvs = convs.map((c) =>
        c.id === currentConversationId ? { ...c, title, updated_at: new Date().toISOString() } : c
      );
      localStorage.setItem('jee_conversations', JSON.stringify(updatedConvs));
      setConversations(updatedConvs);

    } catch (err) {
      console.error('Error sending message:', err);
      setError(
        err instanceof Error
          ? err.message
          : 'Failed to send message. Make sure your Gemini API key is correct.'
      );
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex h-screen bg-gray-100">
      <Sidebar
        conversations={conversations}
        activeConversationId={currentConversationId}
        onSelectConversation={setCurrentConversationId}
        onNewConversation={handleNewConversation}
        onDeleteConversation={handleDeleteConversation}
        isOpen={sidebarOpen}
        onToggle={() => setSidebarOpen(!sidebarOpen)}
      />

      <div className="flex-1 flex flex-col">
        {error && (
          <div className="flex items-center gap-3 p-4 bg-red-100 border-l-4 border-red-500 text-red-700 mx-4 mt-4 rounded">
            <AlertCircle size={20} />
            <div className="flex-1">
              <p className="font-semibold">Error</p>
              <p className="text-sm">{error}</p>
            </div>
            <button
              onClick={() => setError(null)}
              className="text-red-700 hover:text-red-900 font-bold"
            >
              ✕
            </button>
          </div>
        )}

        {currentConversationId && currentConversation ? (
          <ChatContainer
            messages={messages}
            isLoading={isLoading}
            currentConversation={currentConversation}
            onSendMessage={handleSendMessage}
          />
        ) : (
          <div className="flex-1 flex items-center justify-center">
            <div className="text-center">
              <div className="text-5xl mb-4">📚</div>
              <p className="text-gray-600 mb-4">Start a new conversation to begin</p>
              <button
                onClick={handleNewConversation}
                className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2 rounded-lg transition-colors"
              >
                New Conversation
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

export default App;
