import { GoogleGenerativeAI } from '@google/generative-ai';

const apiKey = import.meta.env.VITE_GEMINI_API_KEY;

if (!apiKey) {
  throw new Error('VITE_GEMINI_API_KEY is not set in environment variables');
}

const genAI = new GoogleGenerativeAI(apiKey);

const PHYSICS_SYSTEM_PROMPT = `You are an expert JEE Physics tutor with deep knowledge of mechanics, thermodynamics, electromagnetism, optics, and modern physics. Your role is to help students understand physics concepts clearly and deeply.

Guidelines for responses:
1. Provide step-by-step explanations for problem solving
2. Use mathematical notation and formulas clearly (use LaTeX format with $ $ for inline and $$ $$ for block equations)
3. Explain the underlying physics principles and concepts
4. Break down complex problems into manageable parts
5. Provide relevant examples and analogies
6. Highlight common misconceptions and mistakes
7. When solving numericals, show all steps and unit conversions
8. Use diagrams descriptions when helpful
9. End with a brief summary of key concepts

Always maintain a patient and encouraging tone. Be thorough but concise.`;

export async function getChatResponse(
  userMessage: string,
  conversationHistory: Array<{ role: string; content: string }>,
  imageBase64?: string,
  imageMimeType?: string
): Promise<string> {
  try {
    const model = genAI.getGenerativeModel({ model: 'gemini-1.5-flash' });

    const messageHistory = conversationHistory.map((msg) => ({
      role: msg.role === 'user' ? 'user' : 'model',
      parts: [{ text: msg.content }],
    }));

    const currentMessage: any = {
      role: 'user',
      parts: [{ text: userMessage }],
    };

    if (imageBase64 && imageMimeType) {
      currentMessage.parts.push({
        inlineData: {
          mimeType: imageMimeType,
          data: imageBase64,
        },
      });
    }

    const chat = model.startChat({
      history: messageHistory,
      generationConfig: {
        maxOutputTokens: 2048,
        temperature: 0.7,
      },
    });

    const result = await chat.sendMessage(currentMessage.parts);
    const response = result.response;
    return response.text();
  } catch (error) {
    console.error('Gemini API error:', error);
    throw error;
  }
}
